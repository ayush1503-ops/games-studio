function r(a,o="info"){if(typeof window>"u")return;let e=document.getElementById("admin-toast-container");e||(e=document.createElement("div"),e.id="admin-toast-container",e.className="fixed bottom-6 right-6 z-[100] flex flex-col gap-2.5 w-80 sm:w-96 pointer-events-none",document.body.appendChild(e));const t=document.createElement("div"),n=o==="success"?"bg-moss/10 border-moss text-moss":o==="error"?"bg-coral/10 border-coral text-coral":"bg-grape/10 border-grape text-grape";t.className=`flex items-center justify-between gap-3 rounded-2xl border-2 ${n} bg-cream p-4 shadow-lift pointer-events-auto transition-all duration-300 transform translate-y-2 opacity-0 font-semibold text-xs text-ink`,t.innerHTML=`
    <div class="flex items-center gap-2">
      <span class="font-bold uppercase tracking-wider text-[10px] ${n}">${o}</span>
      <span>${a}</span>
    </div>
    <button class="text-inksoft hover:text-ink cursor-pointer ml-2 text-xs font-bold">✕</button>
  `;const s=t.querySelector("button");s&&(s.onclick=()=>{t.classList.add("opacity-0","translate-y-2"),setTimeout(()=>t.remove(),300)}),e.appendChild(t),requestAnimationFrame(()=>{t.classList.remove("opacity-0","translate-y-2")}),setTimeout(()=>{t.parentNode&&(t.classList.add("opacity-0","translate-y-2"),setTimeout(()=>t.remove(),300))},4e3)}export{r as n};
